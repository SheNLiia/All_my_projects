/* +Param2. Описать функцию MaxNum(A, N) целого типа, находящую номер максимального элемента вещественного массива A размера N.
 * С помощью этой функции найти номера максимальных элементов массивов A, B, C размера NA, NB, NC соответственно. */
/*  ФИО: Мататова Эмилия Сиеновна
 * Дата: 04.05.2025
 * Контрольный пример:
 * input:
 *  1, 3, 7, 9, 2
    4, 6, 2, 8
    10, 20, 15, 5, 30, 25
 * output:
 *  3
    3
    4
 * Время выполнения: 15 минут */

#include <stdio.h>

int MaxNum(int A[], int N) {
    int maxIndex = 0;
    for (int i = 1; i < N; i++) {
        if (A[i] > A[maxIndex]) {
            maxIndex = i;
        }
    }
    return maxIndex;
}

int main() {
    int NA = 5, NB = 4, NC = 6;
    int A[] = {1, 3, 7, 9, 2};
    int B[] = {4, 6, 2, 8};
    int C[] = {10, 20, 15, 5, 30, 25};

    printf("%d\n", MaxNum(A, NA));
    printf("%d\n", MaxNum(B, NB));
    printf("%d\n", MaxNum(C, NC));

    return 0;
}

