/* !Minmax29. Дано целое число N и набор из N целых чисел.
 * Найти максимальное количество подряд идущих минимальных элементов из данного набора.  */
/*  ФИО: Мататова Эмилия Сиеновна
 * Дата: 04.05.2025
 * Контрольный пример:
 * input: 10 3 1 1 2 1 1 1 4 1 1
 * output: 3
 * Время выполнения: 15 минут*/

#include <stdio.h>

int main() {
    int N, x, min, count = 0, maxCount = 0;
    scanf("%d", &N);
    scanf("%d", &x);
    min = x;
    count = 1;
    maxCount = 1;
    for (int i = 1; i < N; i++) {
        scanf("%d", &x);
        if (x < min) {
            min = x;
            count = 1;
            maxCount = 1;
        } else if (x == min) {
            count++;
            if (count > maxCount) maxCount = count;
        } else {
            count = 0;
        }
    }
    printf("%d", maxCount);
    return 0;
}


