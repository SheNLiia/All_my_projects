/* +Text13. Дан непустой текстовый файл. Удалить из него первую строку. */
/*  ФИО: Мататова Эмилия Сиеновна
 * Дата: 04.05.2025
 * Контрольный пример:
 * input:
 *  Это первая строка
    Это вторая строка
    Это третья строка
 * output:
 *  Это вторая строка
    Это третья строка
 * Время выполнения: 15 минут*/

#include <stdio.h>

int main() {
    FILE *f1 = fopen("input.txt", "r");
    FILE *f2 = fopen("temp.txt", "w");
    char c;
    while ((c = fgetc(f1)) != EOF) {
        if (c == '\n' && ftell(f1) > 1) break;
    }
    while ((c = fgetc(f1)) != EOF) {
        fputc(c, f2);
    }
    fclose(f1);
    fclose(f2);
    remove("input.txt");
    rename("temp.txt", "input.txt");
    return 0;
}

