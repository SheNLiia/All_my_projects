#include <stdio.h>
#include <stdlib.h>
#include "Array22.h"

int main() {
    int N, K, L;
    scanf("%d %d %d", &N, &K, &L);

    int *arr = malloc(N * sizeof(int));

    inputarr(arr, N);
    int result = sum(arr, N, K, L);
    printf("%d\n", result);

    free(arr);
    return 0;
}