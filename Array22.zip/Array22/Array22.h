#ifndef ARRAY_H
#define ARRAY_H

void inputarr(int *arr, int N);
int sum(int *arr, int N, int K, int L);

#endif