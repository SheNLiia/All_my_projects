/* Array22. Дан массив размера N и целые числа K и L (1 < K ≤ L ≤ N).
 * Найти сумму всех элементов массива, кроме элементов с номерами от K до L включительно. */
//#include <stdio.h>
//#include <stdlib.h>
//
//int main() {
//    int N, K, L;
//    scanf("%d %d %d", &N, &K, &L);
//
//    int *arr = malloc(N * sizeof(int));
//    for (int i = 0; i < N; i++) {
//        scanf("%d", &arr[i]);
//    }
//
//    int sum = 0;
//    for (int i = 0; i < N; i++) {
//        if (i < K - 1 || i > L - 1) {
//            sum += arr[i];
//        }
//    }
//
//    printf("%d\n", sum);
//    free(arr);
//    return 0;
//}

#include <stdio.h>
#include "Array22.h"

void inputarr(int *arr, int N) {
    for (int i = 0; i < N; i++) {
        scanf("%d", &arr[i]);
    }
}

int sum(int *arr, int N, int K, int L) {
    int sum = 0;
    for (int i = 0; i < N; i++) {
        if (i < K - 1 || i > L - 1) {
            sum += arr[i];
        }
    }
    return sum;
}

