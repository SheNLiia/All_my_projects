#ifndef UI_H
#define UI_H
#define AR_SIZE 100

#include "person.h"

void print_menu();
void add_person(person ar[], int *count);
void delete_person(person ar[], int *count);
void edit_person(person ar[], int count);
void person_choice(int choice, person ar[], int *count);

#endif