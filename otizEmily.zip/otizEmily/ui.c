#include <stdio.h>
#include "ui.h"
#include "person.h"
#include "sort.h"
#include "fileswork.h"

void print_menu() {
    printf("\n===== МЕНЮ =====\n"
           "1. Добавить сотрудника\n"
           "2. Удалить сотрудника\n"
           "3. Редактировать сотрудника\n"
           "4. Сортировать по имени (сохр.)\n"
           "5. Сортировать по отделу (сохр.)\n"
           "6. Сортировать по зарплате (сохр.)\n"
           "0. Выход\n"
           "Ваш выбор: ");
}

void add_person(person ar[], int *count) {
    printf("Введите id, отдел, имя, зарплату и 2 даты (начало и конец):\n");
    scanf("%d %s %s %d", &ar[*count].id, ar[*count].dept, ar[*count].name, &ar[*count].salary);
    scanf("%d.%d.%d", &ar[*count].begin.day, &ar[*count].begin.month, &ar[*count].begin.year);
    scanf("%d.%d.%d", &ar[*count].end.day, &ar[*count].end.month, &ar[*count].end.year);
    (*count)++;
    printf("Добавлено\n");
}

void delete_person(person ar[], int *count) {
    int id;
    printf("Введите id для удаления: ");
    scanf("%d", &id);
    for (int i = 0; i < *count; i++) {
        if (ar[i].id == id) {
            for (int j = i; j < *count - 1; j++) {
                ar[j] = ar[j + 1];
            }
            (*count)--;
            printf("Удалено\n");
            return;
        }
    }
    printf("Не найдено\n");
}

void edit_person(person ar[], int count) {
    int id;
    printf("Введите id для редактирования: ");
    scanf("%d", &id);
    for (int i = 0; i < count; i++) {
        if (ar[i].id == id) {
            printf("Введите новые данные:\n");
            scanf("%d %s %s %d", &ar[i].id, ar[i].dept, ar[i].name, &ar[i].salary);
            scanf("%d.%d.%d", &ar[i].begin.day, &ar[i].begin.month, &ar[i].begin.year);
            scanf("%d.%d.%d", &ar[i].end.day, &ar[i].end.month, &ar[i].end.year);
            printf("Обновлено\n");
            return;
        }
    }
    printf("Не найдено\n");
}

void person_choice(int c, person ar[], int *count) {
    switch (c) {
        case 1: add_person(ar, count); break;
        case 2: delete_person(ar, count); break;
        case 3: edit_person(ar, *count); break;
        case 4: sortName(ar, *count); savefile("sortedname.txt", ar, *count); break;
        case 5: sortDept(ar, *count); savefile("sorteddept.txt", ar, *count); break;
        case 6: sortSalaryAbs(ar, *count); savefile("sortedsalary.txt", ar, *count); break;
        case 0: printf("Выход.\n"); break;
        default: printf("Неверный выбор.\n");
    }
}
