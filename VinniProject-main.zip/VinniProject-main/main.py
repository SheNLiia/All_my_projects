from services.sales_service import SalesService

# Я создаю объект сервиса
service = SalesService()

# Пути к файлам
MANAGERS_FILE = "data/managers.txt"
SALES_FILE = "data/sales.txt"
QUERY1_FILE = "data/query1.txt"

# Меню
def show_menu():
    print("\n--- МЕНЮ ---")
    print("1. О программе")
    print("2. Загрузка из файла менеджеров")
    print("3. Загрузка из файла продаж")
    print("4. Печать списка менеджеров")
    print("5. Печать списка продаж")
    print("6. Выполнение запроса")
    print("0. Выход")

def main():
    # Я загружаю данные из файлов
    service.load_data(MANAGERS_FILE, SALES_FILE)

    item = -1
    while item != 0:
        show_menu()
        try:
            item = int(input("Выберите пункт меню: "))
        except ValueError:
            print("Ошибка: введите число от 0 до 6.")
            continue

        match item:
            case 0:
                print("Спасибо за использование нашей разработки")
            case 1:
                print("Студентка Мататова Эмилия Сиеновна группа 303ИС-22")
                print("Тема проекта: Автосалон Винни-пуха")
            case 2:
                service.managers = SalesService.load_managers(MANAGERS_FILE)
                print("Файл менеджеров загружен в память")
            case 3:
                service.sales = SalesService.load_sales(SALES_FILE)
                print("Файл продаж загружен в память")
            case 4:
                service.show_managers()
            case 5:
                service.show_sales()
            case 6:
                service.save_query1(QUERY1_FILE)
                print(f"Результат сохранён в файле {QUERY1_FILE}")
            case _:
                print("Ошибка: пункты от 0 до 6")

if __name__ == "__main__":
    main()