def read_lines_from_file(filepath: str):
    # Я пробую открыть файл и прочитать все строки
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            return file.readlines()
    except FileNotFoundError:
        print(f"Файл не найден: {filepath}")
        return []
    except Exception as e:
        print(f"Ошибка при чтении файла {filepath}: {e}")
        return []