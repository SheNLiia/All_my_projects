from models.manager import Manager
from models.sale import Sale
from utils.file_handler import read_lines_from_file

class SalesService:
    def __init__(self):
        self.managers = []
        self.sales = []

    def load_data(self, managers_path: str, sales_path: str):
        # Я загружаю менеджеров
        lines = read_lines_from_file(managers_path)
        self.managers = []
        for line in lines:
            try:
                self.managers.append(Manager.from_line(line))
            except Exception as e:
                print(f"Ошибка загрузки менеджера: {e}")

        # Я загружаю продажи
        lines = read_lines_from_file(sales_path)
        self.sales = []
        for line in lines:
            try:
                self.sales.append(Sale.from_line(line))
            except Exception as e:
                print(f"Ошибка загрузки продажи: {e}")

    def show_managers(self):
        for m in self.managers:
            print(m)

    def show_sales(self):
        for s in self.sales:
            print(s)

    def save_query1(self, filepath: str):
        # Я создаю обычный словарь для подсчёта продаж по месяцам
        month_sales = {}

        # Я прохожусь по каждой продаже
        for sale in self.sales:
            # Я создаю ключ в виде строки: "месяц.год"
            month = f"{sale.date.month:02d}.{sale.date.year}"

            # Я увеличиваю счётчик продаж за этот месяц
            if month in month_sales:
                month_sales[month] += 1
            else:
                month_sales[month] = 1

        # Я сохраняю результат в файл
        try:
            with open(filepath, 'w', encoding='utf-8') as file:
                for month in sorted(month_sales):
                    file.write(f"{month}: {month_sales[month]} продаж\n")
            print(f"Данные сохранены в {filepath}")
        except Exception as e:
            print(f"Ошибка при сохранении данных: {e}")

        try:
            with open(filepath, 'w', encoding='utf-8') as file:
                for month in sorted(month_sales):
                    file.write(f"{month}: {month_sales[month]} продаж\n")
            print(f"Данные сохранены в {filepath}")
        except Exception as e:
            print(f"Ошибка при сохранении данных: {e}")

    @staticmethod
    def load_sales(fname):
        sales = []
        try:
            with open(fname, "r", encoding="utf-8") as f:
                for line in f:
                    sales.append(Sale.from_line(line))  # Использую метод из класса Sale
        except FileNotFoundError:
            print(f"Ошибка: файл {fname} не найден.")
        return sales

    @staticmethod
    def load_managers(fname):
        managers = []
        try:
            with open(fname, "r", encoding="utf-8") as f:
                for line in f:
                    managers.append(Manager.from_line(line))  # Использую метод из Manager
        except FileNotFoundError:
            print(f"Ошибка: файл {fname} не найден.")
        return managers
