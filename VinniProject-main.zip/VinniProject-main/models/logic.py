from models import Sale

def read_sales(filepath: str):
    sales = []
    try:
        with open(filepath, 'r', encoding='windows-1251') as file:
            for line in file:
                try:
                    sale = Sale.from_line(line)
                    sales.append(sale)
                except Exception as e:
                    print(f"Ошибка в строке: {line.strip()} — {e}")
    except FileNotFoundError:
        print(f"Файл не найден: {filepath}")
    return sales

def echo_sales(sales):
    print("Список продаж:")
    for sale in sales:
        print(sale)
