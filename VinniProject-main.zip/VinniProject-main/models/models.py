from datetime import datetime

class Sale:
    def __init__(self, date: datetime, manager: str, car: str, price: int):
        self.date = date
        self.manager = manager
        self.car = car
        self.price = price

    @staticmethod
    def from_line(line: str):
        # Я разбираю строку с продажей
        parts = line.strip().split()
        if len(parts) != 4:
            raise ValueError("Строка должна содержать 4 элемента")

        # Я преобразую дату и цену
        date = datetime.strptime(parts[0], "%d.%m.%Y")
        manager = parts[1]
        car = parts[2]
        price = int(parts[3])

        return Sale(date, manager, car, price)

    def __str__(self):
        return f"{self.date.strftime('%d.%m.%Y')} {self.manager} {self.car} {self.price}"
