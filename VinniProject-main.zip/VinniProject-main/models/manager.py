class Manager:
    def __init__(self, manager_id: int, manager_name: str):
        self.manager_id = manager_id
        self.manager_name = manager_name

    def __str__(self):
        return f"{self.manager_id} {self.manager_name}"

    @staticmethod
    def from_line(line: str):
        # Я читаю строку и превращаю её в объект менеджера
        parts = line.strip().split(maxsplit=1)
        if len(parts) != 2:
            raise ValueError("Некорректная строка для менеджера")
        manager_id = int(parts[0])
        manager_name = parts[1]
        return Manager(manager_id, manager_name)