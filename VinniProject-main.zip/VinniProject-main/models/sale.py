from datetime import datetime

class Sale:
    def __init__(self, date: datetime, manager_id: int, car: str, price: int):
        self.date = date
        self.manager_id = manager_id
        self.car = car
        self.price = price

    def __str__(self):
        return f"{self.date.strftime('%d.%m.%Y')} {self.manager_id} {self.car} {self.price}"

    @staticmethod
    def from_line(line: str):
        # Я разбираю строку и создаю из неё продажу
        parts = line.strip().split()
        if len(parts) != 4:
            raise ValueError("Некорректная строка для продажи")
        date = datetime.strptime(parts[0], "%d.%m.%Y")
        manager_id = int(parts[1])
        car = parts[2]
        price = int(parts[3])
        return Sale(date, manager_id, car, price)
