#ifndef SORT_H
#define SORT_H

#include "person.h"

void sortName(person ar[], int len);
void sortDept(person ar[], int len);
void sortSalaryAbs(person ar[], int len);
void sortId(person ar[], int len);

#endif