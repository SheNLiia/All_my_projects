/* Ошибка. Отсутствие базового случая*/
#include <stdio.h>

int finite(int n) {
//    if (n == 0) return 1; // Базовый случай
    return finite(n - 1); // Рекурсивный случай
}