/* Задание 2: Простое ли число принимает функция?  */
#include <stdio.h>
#include <stdbool.h>

// Функция для проверки, является ли число простым
bool is_prime(int n) {
    // Число 1 не является простым
    if (n <= 1) {
        return false;
    }
    // Проверяем делители от 2 до корня из n
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return false; // Если найден делитель, число не простое
        }
    }
    return true; // Если делителей нет, число простое
}

int main() {
    int number;
    // Запросить у пользователя число
    scanf("%d", &number);
    // Вызвать функцию и вывести результат
    if (is_prime(number)) {
        printf("True");
    } else {
        printf("False");
    }

    return 0;
}