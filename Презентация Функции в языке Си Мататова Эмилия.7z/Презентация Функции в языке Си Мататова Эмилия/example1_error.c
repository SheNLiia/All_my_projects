/* Ошибка. Отсутствие вызова макроса va_start*/
#include <stdio.h>
#include <stdarg.h>

void print_numbers(int count, ...) {
    va_list args;
    // Ошибка: va_start не вызван
    for (int i = 0; i < count; i++) {
        printf("%d ", va_arg(args, int)); // Использование неинициализированного va_list
    }
    // Ошибка: va_end не вызван
}